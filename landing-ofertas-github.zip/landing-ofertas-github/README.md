# Landing Page de Ofertas — GitHub Pages

Landing page responsiva em HTML/CSS/JavaScript puro, preparada para ofertas, afiliados e produtos.

## Estrutura

- `index.html` — estrutura da página
- `css/style.css` — visual responsivo
- `js/config.js` — **único arquivo que você normalmente precisa editar**
- `js/app.js` — lógica da aplicação
- `data/` — reservado para catálogos futuros

## Configuração rápida

Abra `js/config.js` e altere:

- `brandName`
- `siteUrl`
- `product.name`
- `product.description`
- `product.images`
- `product.oldPrice`
- `product.currentPrice`
- `product.discount`
- `product.savings`
- `product.buyLink`
- `whatsapp`
- redes sociais
- IDs de analytics

## Publicar no GitHub Pages

1. Crie um repositório no GitHub.
2. Envie todos os arquivos mantendo as pastas.
3. Abra **Settings → Pages**.
4. Em **Build and deployment**, selecione **Deploy from a branch**.
5. Selecione `main` e `/ (root)`.
6. Salve e aguarde a publicação.

## Segurança

Não coloque chaves secretas de OpenAI, Meta, Stripe ou outros serviços neste projeto estático.

Se precisar de OpenAI, use um backend/serverless separado e mantenha a chave em variável de ambiente.

## Importante sobre prova social

Os depoimentos incluídos no template são marcadores demonstrativos. Substitua-os por avaliações reais, verificáveis e autorizadas. Não publique depoimentos fictícios como se fossem de clientes.

## SEO

Antes de publicar, configure `siteUrl` com a URL real do GitHub Pages ou domínio personalizado.

Para domínio próprio, configure também o DNS e o domínio personalizado em **Settings → Pages**.

## Licença

Use e adapte este template conforme as licenças dos serviços externos utilizados. As imagens de exemplo são referências e devem ser substituídas por imagens que você tenha direito de utilizar.
