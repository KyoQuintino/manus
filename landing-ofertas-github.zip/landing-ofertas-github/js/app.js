(() => {
  "use strict";
  const C = window.OFFER_CONFIG;
  const $ = id => document.getElementById(id);
  const product = C.product;

  function setText(id, value){ const el=$(id); if(el) el.textContent=value ?? ""; }
  function setHref(id, value){ const el=$(id); if(el) el.href=value || "#"; }

  function track(eventName, params={}) {
    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push({event:eventName, ...params});
    if(typeof window.gtag === "function") window.gtag("event", eventName, params);
    if(typeof window.fbq === "function") window.fbq("trackCustom", eventName, params);
  }

  function renderMeta(){
    const title = `${product.name} | Oferta Especial`;
    const desc = `${product.name}. ${product.description}`;
    document.title = title;
    $("seo-description").content = desc;
    $("og-title").content = title;
    $("og-description").content = desc;
    $("og-image").content = product.images[0] || "";
    $("og-url").content = C.siteUrl;
    $("canonical-url").href = C.siteUrl;
  }

  function renderGallery(){
    const main=$("main-product-image"), box=$("gallery-thumbnails");
    if(!product.images?.length) return;
    main.src=product.images[0]; main.alt=product.name;
    product.images.forEach((src,i)=>{
      const img=document.createElement("img");
      img.src=src; img.alt=`${product.name} — imagem ${i+1}`; img.loading="lazy";
      img.className=`thumb ${i===0?"active":""}`;
      img.addEventListener("click",()=>{
        main.src=src;
        box.querySelectorAll(".thumb").forEach(x=>x.classList.remove("active"));
        img.classList.add("active");
      });
      box.appendChild(img);
    });
  }

  function renderBenefits(){
    const box=$("benefits");
    (C.benefits||[]).forEach(([icon,title,text])=>{
      const el=document.createElement("article"); el.className="benefit";
      el.innerHTML=`<div class="benefit-icon"><i data-lucide="${icon}"></i></div><div><h3></h3><p></p></div>`;
      el.querySelector("h3").textContent=title; el.querySelector("p").textContent=text; box.appendChild(el);
    });
  }

  function renderTestimonials(){
    const box=$("testimonials");
    (C.testimonials||[]).forEach(item=>{
      const el=document.createElement("article"); el.className="testimonial";
      el.innerHTML=`<div class="stars" aria-label="Avaliação">★★★★★</div><p></p><strong></strong>`;
      el.querySelector("p").textContent=item.text; el.querySelector("strong").textContent=`— ${item.author}`;
      box.appendChild(el);
    });
  }

  function renderFaq(){
    const box=$("faq");
    (C.faq||[]).forEach(([q,a],i)=>{
      const el=document.createElement("div"); el.className="faq-item";
      const button=document.createElement("button"); button.className="faq-question"; button.type="button";
      button.setAttribute("aria-expanded","false");
      button.innerHTML=`<span></span><i data-lucide="chevron-down"></i>`;
      button.querySelector("span").textContent=q;
      const answer=document.createElement("div"); answer.className="faq-answer"; answer.textContent=a;
      button.addEventListener("click",()=>{
        const open=el.classList.toggle("open"); button.setAttribute("aria-expanded",String(open));
      });
      el.append(button,answer); box.appendChild(el);
    });
  }

  function setupLinks(){
    ["hero-buy","final-buy","mobile-buy"].forEach(id=>{
      setHref(id, product.buyLink);
      $(id)?.addEventListener("click",()=>track("click_buy",{location:id,product:product.name}));
    });
    const msg=encodeURIComponent(`Olá! Vi a oferta do ${product.name} e gostaria de saber mais.`);
    const wa=`https://wa.me/${C.whatsapp}?text=${msg}`;
    setHref("whatsapp-float",wa); setHref("whatsapp-footer",wa);
    setHref("instagram-link",C.social?.instagram); setHref("facebook-link",C.social?.facebook);
    $("whatsapp-float")?.addEventListener("click",()=>track("click_whatsapp"));
  }

  function init(){
    setText("brand-name",C.brandName); setText("footer-brand",C.brandName); setText("footer-copy-brand",C.brandName);
    setText("year",new Date().getFullYear());
    setText("product-name",product.name); setText("product-description",product.description);
    setText("old-price",product.oldPrice); setText("current-price",product.currentPrice); setText("mobile-price",product.currentPrice);
    setText("discount-badge",product.discount); setText("savings",`Economize ${product.savings}`);
    $("brand-link").href=C.siteUrl || "#";
    renderMeta(); renderGallery(); renderBenefits(); renderTestimonials(); renderFaq(); setupLinks();
    if(window.lucide) window.lucide.createIcons();

    let fired50=false,fired90=false;
    window.addEventListener("scroll",()=>{
      const max=document.documentElement.scrollHeight-window.innerHeight;
      const pct=max>0?(window.scrollY/max)*100:100;
      if(pct>=50&&!fired50){fired50=true;track("scroll_50");}
      if(pct>=90&&!fired90){fired90=true;track("scroll_90");}
    },{passive:true});
  }

  document.addEventListener("DOMContentLoaded",init);
})();
