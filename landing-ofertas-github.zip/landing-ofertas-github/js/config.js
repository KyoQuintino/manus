// Edite apenas este arquivo para trocar a oferta.
window.OFFER_CONFIG = {
  brandName: "Sua Marca Oficial",
  siteUrl: "https://SEU-USUARIO.github.io/SEU-REPOSITORIO/",
  product: {
    name: "Fone de Ouvido Bluetooth Pro Sound Max",
    description: "Cancelamento de ruído ativo, bateria de até 24 horas, som cristalino e ajuste ergonômico para treinos, trabalho e dia a dia.",
    images: [
      "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=1000&q=85",
      "https://images.unsplash.com/photo-1484704849700-f032a568e944?auto=format&fit=crop&w=1000&q=85",
      "https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&w=1000&q=85"
    ],
    oldPrice: "R$ 299,90",
    currentPrice: "R$ 147,00",
    discount: "50% OFF",
    savings: "R$ 152,90",
    buyLink: "https://plataformaoficial.com/seu-link-de-afiliado-ou-loja"
  },
  benefits: [
    ["sparkles","Excelente custo-benefício","Qualidade e recursos apresentados por um preço promocional."],
    ["layers","Design moderno","Visual pensado para combinar com diferentes estilos e ocasiões."],
    ["zap","Prático para o dia a dia","Uma solução conveniente para trabalho, treino e momentos de lazer."],
    ["smile","Mais praticidade","Recursos pensados para tornar o uso simples e confortável."],
    ["gift","Ótima opção para presente","Uma alternativa interessante para presentear alguém especial."],
    ["shield-check","Compra direcionada","Finalize a compra diretamente na plataforma oficial do fornecedor."]
  ],
  testimonials: [
    {text:"Substitua este conteúdo por uma avaliação real e verificável do produto.", author:"Avaliação real — nome do cliente"},
    {text:"Substitua este conteúdo por uma avaliação real e verificável do produto.", author:"Avaliação real — nome do cliente"},
    {text:"Substitua este conteúdo por uma avaliação real e verificável do produto.", author:"Avaliação real — nome do cliente"}
  ],
  faq: [
    ["Como faço para comprar?","Clique em um dos botões de compra. Você será encaminhado para a página oficial indicada no cadastro da oferta."],
    ["Para onde o botão de compra me leva?","Ele abre o link configurado em product.buyLink. Confirme sempre que o endereço é o fornecedor ou parceiro correto."],
    ["O preço está garantido?","Não. Preços, estoque, frete e condições podem mudar. Confirme os valores na página oficial antes de concluir."],
    ["Quais formas de pagamento estão disponíveis?","As formas de pagamento são definidas pelo fornecedor e devem ser verificadas no checkout oficial."],
    ["Como funciona o envio?","Prazo, frete e rastreamento dependem do fornecedor e aparecem no processo de compra."],
    ["O produto tem garantia?","Consulte a política de garantia do fornecedor e as condições aplicáveis ao produto antes da compra."]
  ],
  whatsapp: "5527999999999",
  social: {
    instagram: "https://instagram.com/suamarca",
    facebook: "https://facebook.com/suamarca"
  },
  analytics: {
    gaMeasurementId: "",
    metaPixelId: "",
    tiktokPixelId: ""
  }
};
